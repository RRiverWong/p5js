let cols, rows;
let scale = 20;
let terrain = [];
let seedInput, scaleInput, heightInput, detailInput;
let button;
let seedValue = 0;
let heightRange = 100;
let noiseDetailLevel = 0.1;
let player;
let gravity = 1;
let jumpPower = -15;
let velocityY = 0;
let isJumping = false;

function setup() {
  createCanvas(600, 400, WEBGL);
  createUI();
  generateTerrain();
  player = { x: width / 2, y: height / 2, z: 50, speed: 5 };
}

function createUI() {
  seedInput = createInput("100");
  seedInput.position(10, height + 10);
  
  scaleInput = createInput("20");
  scaleInput.position(10, height + 40);
  
  heightInput = createInput("100");
  heightInput.position(10, height + 70);
  
  detailInput = createInput("0.1");
  detailInput.position(10, height + 100);
  
  button = createButton("Go");
  button.position(200, height + 10);
  button.mousePressed(generateTerrain);
  
  createP("Seed").position(150, height + 5);
  createP("Scale").position(150, height + 35);
  createP("Height Range").position(150, height + 65);
  createP(" Noise Detail").position(150, height + 95);
}

function generateTerrain() {
  seedValue = int(seedInput.value());
  scale = int(scaleInput.value());
  heightRange = int(heightInput.value());
  noiseDetailLevel = float(detailInput.value());
  
  noiseSeed(seedValue);
  cols = floor(width / scale);
  rows = floor(height / scale);
  terrain = [];
  
  for (let y = 0; y < rows; y++) {
    let row = [];
    for (let x = 0; x < cols; x++) {
      let heightValue = map(noise(x * noiseDetailLevel, y * noiseDetailLevel), 0, 1, -heightRange, heightRange);
      row.push(heightValue);
    }
    terrain.push(row);
  }
}

function draw() {
  background(0);
  rotateX(PI / 3);
  translate(-width / 2, -height / 2);
  
  for (let y = 0; y < rows - 1; y++) {
    beginShape(TRIANGLE_STRIP);
    for (let x = 0; x < cols; x++) {
      let brightness = terrain[y][x] > 0 ? 255 : 0;
      fill(brightness);
      stroke(brightness);
      vertex(x * scale, y * scale, terrain[y][x]);
      vertex(x * scale, (y + 1) * scale, terrain[y + 1][x]);
    }
    endShape();
  }
  
  updatePlayer();
  drawPlayer();
}

function drawPlayer() {
  push();
  let brightness = player.z > 0 ? 255 : 0;
  fill(brightness);
  stroke(brightness);
  translate(player.x - width / 2, player.y - height / 2, player.z);
  sphere(10);
  pop();
}

function updatePlayer() {
  let gridX = floor(player.x / scale);
  let gridY = floor(player.y / scale);
  
  if (gridX >= 0 && gridX < cols && gridY >= 0 && gridY < rows) {
    let groundHeight = terrain[gridY][gridX];
    player.z += velocityY;
    velocityY += gravity;
    
    if (player.z >= groundHeight + 10) { // Collide with terrain
      player.z = groundHeight + 10;
      velocityY = 0;
      isJumping = false;
    }
  }
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) player.x -= player.speed;
  if (keyCode === RIGHT_ARROW) player.x += player.speed;
  if (keyCode === UP_ARROW) player.y -= player.speed;
  if (keyCode === DOWN_ARROW) player.y += player.speed;
  
  if (key === ' ' && !isJumping) { // Jump
    velocityY = jumpPower;
    isJumping = true;
  }
}


